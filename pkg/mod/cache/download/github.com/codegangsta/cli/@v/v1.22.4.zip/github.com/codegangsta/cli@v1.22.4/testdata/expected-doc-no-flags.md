% greet(8) 

% Harrison

# NAME

greet - Some app

# SYNOPSIS

greet

# DESCRIPTION

app [first_arg] [second_arg]

**Usage**:

```
greet [GLOBAL OPTIONS] command [COMMAND OPTIONS] [ARGUMENTS...]
```

# COMMANDS

## config, c

another usage test

**--another-flag, -b**: another usage text

**--flag, --fl, -f**="": 

### sub-config, s, ss

another usage test

**--sub-command-flag, -s**: some usage text

**--sub-flag, --sub-fl, -s**="": 

## info, i, in

retrieve generic information

## some-command


